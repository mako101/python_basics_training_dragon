#Draw the class diagram of the below case study
#Using Inheritance, create an application that allows users to calculate the area, perimeter, circumference where necessary
#for a circle, triangle, and rectangle
#The application should ask users what shape they intend to calculate
# for rectangle, the system should display the area and perimeter using the rectangle formula
# for triangle, the system should display the area and perimeter using the triangle formula
# for circle, the system should display the area and circumference using the circle formula

#Handle all exceptions where necessary
#Use google to obtain information on the formulas if unknown