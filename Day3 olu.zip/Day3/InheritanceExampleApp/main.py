import animal, dog

#create an instance of animal
anim = animal.Animal("DarkAnim")

anim.speak()

print(anim)

#line space
print()


#create an instance of Dog
dg = dog.Dog("Bingo", 5)

dg.speak()

print(dg)

#Exercise
#create a class called cat that will inherit from the superclass called Animal
#implement the features as done for dog class
#create an instance of the cat class to show or test this behaviour as done above